﻿using ParkolohazSzimulacio;


Szerver szerver = new Szerver();
Thread szal=new Thread(new ThreadStart(szerver.Szolgaltatas));
szal.Start();
Thread auto=new Thread(new ThreadStart(AutokMozgasa));
auto.Start();
while (true) ;

void AutokMozgasa()
{
    Random vszg = new Random();
    while(true)
    {
        Kliens auto=new Kliens();
        Thread.Sleep(vszg.Next(5000,10000));
    }
}
