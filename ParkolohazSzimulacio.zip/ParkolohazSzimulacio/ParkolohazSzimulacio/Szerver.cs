﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ParkolohazSzimulacio
{
    internal class Szerver
    {
        TcpListener figyelo;
        private readonly Dictionary<string, string> entryTimes = new(); //a belépések figyeléshez directorit használunk
        private readonly object dictLock = new();

        public Szerver() {
            IPAddress localhost = IPAddress.Parse("127.0.0.1");     //server IP címe
            figyelo = new TcpListener(localhost, 2025);     //ezen a portszámon és IP-n figyeljük a csoamgokat
            figyelo.Start();
            Console.WriteLine("Szerver: START");    //ha beindult a szerver akkor kiírjuk, hogy START

            
            // Ezzel törölni tudjuk indításoknál a .txt fájlban az adatokat & függetlenül működik a 2
            string logDirectory = "Rendszámok";     
            Directory.CreateDirectory(logDirectory);
            string logFilePath = Path.Combine(logDirectory, "parkolasok.txt");      //az alapértelmezett helyen létrehozzuk a parkolasok.xtx-t
            File.WriteAllText(logFilePath, string.Empty);       //kitörlünk minden előző adatot
            
        }

        public void Szolgaltatas()
        {
            string logDirectory = "Rendszámok";     //létrehozzuk a Rendszámok mappát
            string logFilePath = Path.Combine(logDirectory, "parkolasok.txt");      //amibe létrehozzuk a parkolasok.txt fájlt
            const int ratePerMinute = 5;     //megadjuk a percenkénti fizetendőt

            while (true)
            {
                TcpClient kliens = figyelo.AcceptTcpClient();
                NetworkStream csatorna = kliens.GetStream();
                StreamReader request = new StreamReader(csatorna);
                string numberPlate = request.ReadToEnd().Trim();        //a rendszám olvasása a request csomagből a klienstől
                string timestamp = DateTime.Now.ToString("yyyy.MM.dd. HH.mm");      //az időpont feljegyzése megadott formátumban

                string logLine = "";

                lock (dictLock)
                {
                    // megnézzük, hogy a rendszám már bent van-e
                    if (!entryTimes.ContainsKey(numberPlate))
                    {
                        // elmentjük a belépési időt
                        entryTimes[numberPlate] = timestamp;

                        logLine = $"{numberPlate}\t{timestamp}";

                        // kiírjuk a belépési adatokat a fájlba
                        File.AppendAllText(logFilePath, logLine + Environment.NewLine);
                    }
                    else
                    {
                        // kilép az autó, lekérjük és kitöröljük a belépési időt
                        string entryTime = entryTimes[numberPlate];
                        entryTimes.Remove(numberPlate);

                        // letöltött idő kalculálása
                        DateTime entryDateTime = DateTime.ParseExact(entryTime, "yyyy.MM.dd. HH.mm", null);
                        DateTime exitDateTime = DateTime.ParseExact(timestamp, "yyyy.MM.dd. HH.mm", null);
                        int minutes = (int)(exitDateTime - entryDateTime).TotalMinutes;

                        // fizetendő számolása
                        int payment = minutes * ratePerMinute;

                        // mindent kiírunk egy sorba
                        logLine = $"{numberPlate}\t{entryTime}\t{timestamp}\t{payment}";

                        // kiírjuk a kilépési adatokat a fájlba
                        File.AppendAllText(logFilePath, logLine + Environment.NewLine);
                    }
                }

                Console.WriteLine($"SZERVER olvasta: {numberPlate} {timestamp}");
                StreamWriter response = new StreamWriter(csatorna) { AutoFlush = true };
                response.WriteLine("OK");
            }
        }

        ~Szerver()
        {
            Console.WriteLine("Szerver: STOP");
            Console.ReadKey();
        }
    }
}
